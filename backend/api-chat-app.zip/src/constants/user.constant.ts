export enum USER_STATUS {
  ACTIVE = 'Active',
  RESTRICTED = 'Restricted',
  DISABLED = 'Disabled',
}
