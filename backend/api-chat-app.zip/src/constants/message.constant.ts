export enum MESSAGE_STATUS {
  DELIVERED = 'delivered',
  DELETED = 'deleted',
  EDITED = 'edited',
}
