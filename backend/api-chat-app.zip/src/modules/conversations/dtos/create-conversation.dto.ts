export interface CreateConversationDto {
  lastMessage: string;
  member1: string;
  member2: string;
  senderId: string;
}
