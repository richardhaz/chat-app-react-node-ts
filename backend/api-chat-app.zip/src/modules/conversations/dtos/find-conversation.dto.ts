export interface FindConversationDto {
  member1: string;
  member2: string;
}
