export interface UpdateConversationDto {
  conversationId: string;
  lastMessage: string;
  senderId: string;
}
