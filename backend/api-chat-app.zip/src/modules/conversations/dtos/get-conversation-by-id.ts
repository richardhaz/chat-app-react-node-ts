export interface GetConversationByIdDto {
  conversationId: string;
}
