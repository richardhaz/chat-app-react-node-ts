export interface FindAllMyConversationsDto {
  senderId: string;
}
