import { Response } from 'express';

export const login = (res: Response) => {};
export const AuthService = { login };
