export interface LoginUserDto {
  email: string;
  password: string;
}
