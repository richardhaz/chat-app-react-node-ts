export interface GetChatMessageDto {
  from: string;
  to: string;
}
