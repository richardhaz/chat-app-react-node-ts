export interface CreateMessageDto {
  from: string;
  to: string;
  message: string;
  messageIdentifier: string;
}
