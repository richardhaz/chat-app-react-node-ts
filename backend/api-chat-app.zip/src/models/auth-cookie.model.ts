export interface AuthCookieModel {
  access: string;
  loggedIn: string;
}
