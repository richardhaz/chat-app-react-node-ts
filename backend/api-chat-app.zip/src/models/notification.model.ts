export interface NotificationModel {
  _id: string;
  context: string;
  senderId: string;
  seen: boolean;
  createdAt: string;
  updatedAt: string;
}
