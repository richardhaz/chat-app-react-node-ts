export const TimeHelper = {
  ONE_DAY: 1000 * 86400,
  ONE_WEEK: 1000 * 86400 * 7,
};
