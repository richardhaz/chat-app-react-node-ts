const MONGO_ID = /^[0-9a-fA-F]{24}$/;

export const REGEX = { MONGO_ID };
