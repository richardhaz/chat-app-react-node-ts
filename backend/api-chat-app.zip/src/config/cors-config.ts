export const corsConfig = {
  credentials: true,
  methods: 'GET, POST, PUT, PATCH, DELETE',
  origin: ['http://localhost:5173', 'http://localhost:3000'],
};
